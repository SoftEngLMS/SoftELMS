﻿CREATE TABLE [dbo].[LoginTable]
(
	[UserId] INT NOT NULL PRIMARY KEY, 
    [UserName] NCHAR(20) NOT NULL, 
    [Pasword] NCHAR(20) NOT NULL, 
    CONSTRAINT [AK_LoginTable_Column] UNIQUE (UserName)
)
	
	



		
