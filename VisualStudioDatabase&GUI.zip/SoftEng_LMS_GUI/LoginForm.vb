﻿Imports System.Data.SqlClient

Public Class Form1


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub LoginButton_Click(sender As Object, e As EventArgs) Handles LoginButton.Click

        Dim connection As New SqlConnection("Server = (localdb)\ProjectsV13; Database = SoftEngLMS; Integrated Security = true")
        Dim command As New SqlCommand("select * from LoginTable where UserName = @username and Password = @password", connection)

        command.Parameters.Add("@username", SqlDbType.VarChar).Value = UserTextBox.Text
        command.Parameters.Add("@password", SqlDbType.VarChar).Value = PassTextBox.Text

        Dim adapter As New SqlDataAdapter(command)
        Dim loginTable As New DataTable()
        adapter.Fill(loginTable)

        If loginTable.Rows.Count() <= 0 Then

            MessageBox.Show("Username or Password is invalid")

        Else
            MessageBox.Show("Login succesfull")
            Dim profForm As New ProfessorForm()
            Me.Hide()
            profForm.Show()


        End If
    End Sub

    Private Sub CloseButton_Click(sender As Object, e As EventArgs) Handles CloseButton.Click
        Me.Close()
    End Sub
End Class
