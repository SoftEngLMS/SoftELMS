﻿Public Class ProfessorForm
    Private Sub ProfessorForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class